# MCP Medical Server Documentation

## Overview

The `mcp_medical_server.py` is a Model Context Protocol (MCP) server that provides medical knowledge retrieval using ChromaDB and BGE embeddings. It serves as the central database access layer for medical information and can be accessed via both MCP protocol and HTTP API.

## Architecture

```
MCP Clients → MCP Server → ChromaDB
HTTP Clients → HTTP API → ChromaDB
```

## Key Components

### 1. TTLCache Class

**Purpose**: Time-to-live cache implementation to prevent memory bloat in long-running sessions.

**Features**:
- Automatic expiration of cached entries
- Configurable TTL (default: 1 hour)
- Memory-efficient storage
- Automatic cleanup of expired entries

**Methods**:
- `get(key)`: Retrieve cached value if not expired
- `set(key, value)`: Store value with timestamp
- `clear_expired()`: Remove expired entries
- `size()`: Get current cache size

### 2. MedicalDatabase Class

**Purpose**: Core database operations using ChromaDB with BGE embeddings.

**Key Methods**:
- `search_knowledge(query, top_k)`: General medical search
- `search_by_condition(condition)`: Condition-specific search
- `search_by_treatment(treatment)`: Treatment-specific search
- `search_by_symptom(symptom)`: Symptom-specific search
- `get_statistics()`: Database statistics and health

**Features**:
- TTL-based caching
- ChromaDB integration
- BGE embedding support
- Error handling and logging

### 3. MCP Server Implementation

**Purpose**: Provides MCP protocol tools for medical knowledge access.

**Available Tools**:
1. `search_medical_knowledge`: General medical search
2. `search_by_condition`: Medical condition search
3. `search_by_treatment`: Treatment search
4. `search_by_symptom`: Symptom search
5. `get_database_info`: Database statistics

### 4. HTTP Server

**Purpose**: Provides HTTP API for client communication.

**Endpoints**:
- `POST /mcp_tool`: Tool execution endpoint
- `GET /health`: Health check endpoint

## Configuration

### Environment Variables
- No API keys required (uses local BGE embeddings)
- Database path: `./chroma_db_collective`
- Collection name: `books_collection`
- Embedding model: `BAAI/bge-small-en-v1.5`

### Dependencies
```bash
pip install mcp chromadb sentence-transformers python-dotenv flask
```

## MCP Tools

### 1. search_medical_knowledge

**Description**: Search the medical knowledge database for general medical information.

**Parameters**:
- `query` (required): Medical question or topic
- `top_k` (optional): Number of results (default: 5, max: 10)
- `max_length` (optional): Content snippet length (default: 500, max: 2000)

**Example**:
```json
{
  "query": "diabetes treatment options",
  "top_k": 3,
  "max_length": 800
}
```

### 2. search_by_condition

**Description**: Search specifically for medical condition information.

**Parameters**:
- `condition` (required): Medical condition name
- `max_length` (optional): Content snippet length (default: 400, max: 2000)

**Example**:
```json
{
  "condition": "diabetes",
  "max_length": 600
}
```

### 3. search_by_treatment

**Description**: Search for medical treatment information.

**Parameters**:
- `treatment` (required): Treatment name
- `max_length` (optional): Content snippet length (default: 400, max: 2000)

**Example**:
```json
{
  "treatment": "insulin therapy",
  "max_length": 500
}
```

### 4. search_by_symptom

**Description**: Search for symptom information and causes.

**Parameters**:
- `symptom` (required): Symptom name
- `max_length` (optional): Content snippet length (default: 400, max: 2000)

**Example**:
```json
{
  "symptom": "chest pain",
  "max_length": 400
}
```

### 5. get_database_info

**Description**: Get database statistics and status.

**Parameters**: None

**Response**:
```json
{
  "total_documents": 120598,
  "collection_name": "books_collection",
  "embedding_model": "BAAI/bge-small-en-v1.5",
  "database_path": "./chroma_db_collective",
  "cache_size": 15,
  "status": "operational"
}
```

## HTTP API

### POST /mcp_tool

**Purpose**: Execute MCP tools via HTTP.

**Request**:
```json
{
  "tool_name": "search_medical_knowledge",
  "arguments": {
    "query": "diabetes treatment",
    "top_k": 3
  }
}
```

**Response**:
```json
{
  "query": "diabetes treatment",
  "results_count": 3,
  "results": [
    {
      "rank": 1,
      "content": "Diabetes treatment involves...",
      "source": "medical_book_chunk_1",
      "similarity": 0.85,
      "relevance_score": "85%"
    }
  ]
}
```

### GET /health

**Purpose**: Health check and status.

**Response**:
```json
{
  "status": "running",
  "database": "connected",
  "tools": [
    "search_medical_knowledge",
    "search_by_condition",
    "search_by_treatment",
    "search_by_symptom",
    "get_database_info"
  ]
}
```

## Database Structure

### ChromaDB Collection
- **Name**: `books_collection`
- **Path**: `./chroma_db_collective`
- **Embedding Model**: BGE (BAAI/bge-small-en-v1.5)
- **Documents**: Medical literature and knowledge

### Metadata Structure
```json
{
  "filename": "medical_book.txt",
  "chunk_id": "1",
  "source": "medical_literature"
}
```

## Caching System

### TTL Cache Features
- **TTL**: 1 hour (configurable)
- **Automatic Cleanup**: Expired entries removed on statistics calls
- **Memory Efficient**: Prevents memory bloat in long-running sessions
- **Cache Keys**: Based on query and parameters

### Cache Management
```python
# Cache configuration
CACHE_TTL_SECONDS = 3600  # 1 hour

# Automatic cleanup
expired_count = self._search_cache.clear_expired()
```

## Error Handling

### Database Errors
- Connection failures logged and reported
- Collection access errors handled gracefully
- Embedding function errors caught and logged

### Tool Execution Errors
- Parameter validation
- Query processing errors
- Response formatting errors

### HTTP API Errors
- JSON parsing errors
- Tool execution errors
- Connection timeouts

## Logging

### Log Levels
- **INFO**: Normal operations, search queries, cache hits
- **ERROR**: Database errors, tool execution failures
- **DEBUG**: Detailed operation information

### Log Format
```
2024-01-15 10:30:00,123 - INFO - SEARCH: 'diabetes treatment' (top_k=3)
2024-01-15 10:30:00,456 - INFO - ✓ Found 3 results
```

## Performance Features

### 1. TTL Caching
- Reduces database queries for repeated searches
- Automatic memory management
- Configurable expiration times

### 2. Response Truncation
- Configurable content length limits
- Prevents oversized responses
- Improves performance for large documents

### 3. Parameter Validation
- Input sanitization
- Parameter capping (top_k max: 10, max_length max: 2000)
- Error handling for invalid inputs

## Usage Examples

### MCP Protocol Usage
```python
# MCP client connection
from mcp import ClientSession
from mcp.client.stdio import stdio_client

# Connect to server
async with stdio_client(server_params) as (read, write):
    async with ClientSession(read, write) as session:
        # Call tool
        result = await session.call_tool(
            "search_medical_knowledge",
            {"query": "diabetes treatment", "top_k": 3}
        )
```

### HTTP API Usage
```bash
# Search medical knowledge
curl -X POST http://localhost:8000/mcp_tool \
  -H "Content-Type: application/json" \
  -d '{
    "tool_name": "search_medical_knowledge",
    "arguments": {
      "query": "diabetes treatment",
      "top_k": 3
    }
  }'

# Health check
curl http://localhost:8000/health
```

## Development

### Running the Server
```bash
python mcp_medical_server.py
```

### Prerequisites
1. ChromaDB database at `./chroma_db_collective`
2. Collection named `books_collection`
3. All dependencies installed

### Testing
```bash
# Test HTTP API
curl -X POST http://localhost:8000/mcp_tool \
  -H "Content-Type: application/json" \
  -d '{"tool_name": "get_database_info", "arguments": {}}'

# Test health
curl http://localhost:8000/health
```

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Verify ChromaDB path exists
   - Check collection name matches configuration
   - Ensure database is not corrupted

2. **Embedding Model Issues**
   - BGE model downloads automatically on first use
   - Check internet connection for model download
   - Verify sentence-transformers installation

3. **Memory Issues**
   - TTL cache automatically manages memory
   - Check cache size via `get_database_info`
   - Adjust `CACHE_TTL_SECONDS` if needed

### Debug Information

- All operations logged with timestamps
- Database statistics available via tools
- Cache performance tracked
- Error details included in responses

## Production Considerations

### Performance
- TTL caching reduces database load
- Response truncation prevents memory issues
- Parameter validation prevents errors

### Monitoring
- Health check endpoint for status
- Database statistics for monitoring
- Cache performance tracking

### Security
- No API keys required (local embeddings)
- Input validation and sanitization
- Error message sanitization
