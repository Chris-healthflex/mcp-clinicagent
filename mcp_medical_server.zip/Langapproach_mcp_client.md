# Langapproach MCP Client Documentation

## Overview

The `Langapproach_mcp_client.py` is a Flask-based HTTP API server that provides medical knowledge search capabilities by connecting to the MCP Medical Server. It uses LangChain for intelligent agent-based responses and maintains conversation context.

## Architecture

```
User Request → Flask API → MCP Client → MCP Server → ChromaDB
```

## Key Components

### 1. MCPMedicalClient Class

**Purpose**: Handles communication with the MCP Medical Server via HTTP requests.

**Key Methods**:
- `search_medical_knowledge(query, top_k)`: General medical search
- `search_by_condition(condition)`: Condition-specific search
- `search_by_treatment(treatment)`: Treatment-specific search
- `search_by_symptom(symptom)`: Symptom-specific search
- `get_database_info()`: Database statistics

**Communication**: Uses HTTP requests to `http://localhost:8000/mcp_tool`

### 2. MCPMedicalRetriever Class

**Purpose**: LangChain retriever that converts MCP responses into multiple Document objects for better RAG.

**Key Features**:
- Parses MCP responses into individual documents
- Extracts source metadata
- Returns multiple documents instead of single large document
- Better for RetrievalQA chains

### 3. MCPMedicalSystem Class

**Purpose**: Main LangChain system that orchestrates all components.

**Components**:
- **LLM**: GPT-3.5-turbo for response generation
- **Memory**: ConversationBufferMemory for context
- **Tools**: MCP-based search tools
- **Agent**: Zero-shot ReAct agent with memory
- **Retriever**: MCP-based document retriever

## API Endpoints

### POST /fast_ask
**Purpose**: Fast medical search using MCP server directly.

**Request**:
```json
{
  "question": "diabetes treatment options"
}
```

**Response**:
```json
{
  "question": "diabetes treatment options",
  "answer": "Found 3 results: ...",
  "approach": "MCP Server Integration",
  "processing_time": "1.23s",
  "optimizations": ["MCP Client", "No Code Duplication", "Centralized Database"]
}
```

### POST /agent_ask
**Purpose**: Intelligent agent-based responses with conversation context.

**Request**:
```json
{
  "question": "what exercises can I do for this condition?"
}
```

**Response**:
```json
{
  "question": "what exercises can I do for this condition?",
  "answer": "Based on our previous discussion about adductor strain...",
  "approach": "MCP-Integrated LangChain Agent with Context",
  "processing_time": "2.45s",
  "context_used": "Previous discussion involved: adductor, strain"
}
```

### POST /retrieval_ask
**Purpose**: RetrievalQA-based responses using MCP retriever.

**Request**:
```json
{
  "question": "symptoms of diabetes"
}
```

**Response**:
```json
{
  "question": "symptoms of diabetes",
  "answer": "Based on the medical literature...",
  "approach": "MCP-Integrated RetrievalQA",
  "processing_time": "1.87s"
}
```

### GET /health
**Purpose**: System health and status check.

**Response**:
```json
{
  "status": "optimal",
  "database_info": "Connected to ChromaDB with 120,598 documents",
  "memory": {
    "memory_length": 4,
    "has_memory": true,
    "recent_messages": ["User: adductor pain", "Assistant: I understand you're experiencing adductor pain..."]
  },
  "conversation_context": "Previous discussion involved: adductor, strain",
  "architecture": "MCP Client + Flask Server"
}
```

### POST /memory/clear
**Purpose**: Clear agent conversation memory.

**Response**:
```json
{
  "status": "success",
  "message": "Agent memory cleared",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### GET /memory/status
**Purpose**: Get current memory status and context.

**Response**:
```json
{
  "status": "success",
  "memory": {
    "memory_length": 4,
    "has_memory": true
  },
  "conversation_context": "Previous discussion involved: adductor, strain",
  "raw_memory": {
    "chat_history_length": 4,
    "recent_messages": ["User: adductor pain", "Assistant: I understand..."]
  }
}
```

## Configuration

### Environment Variables
- `OPENAI_API_KEY`: Required for GPT-3.5-turbo LLM

### Dependencies
```bash
pip install flask langchain langchain-openai requests python-dotenv
```

## Key Features

### 1. Context Awareness
- Maintains conversation history
- Extracts specific medical terms from previous conversations
- Uses context to enhance search queries
- Remembers conditions, symptoms, and treatments discussed

### 2. Intelligent Query Enhancement
- Automatically enhances queries based on context
- Adds relevant medical terms to improve search results
- Maintains specificity for better results

### 3. Multiple Response Modes
- **Fast Search**: Direct MCP server calls
- **Agent Mode**: Intelligent reasoning with tools
- **RetrievalQA**: Document-based question answering

### 4. Error Handling
- Graceful fallbacks when agent reaches limits
- Connection error handling for MCP server
- Comprehensive error logging

## Usage Examples

### Basic Medical Search
```bash
curl -X POST http://localhost:5000/fast_ask \
  -H "Content-Type: application/json" \
  -d '{"question": "diabetes symptoms"}'
```

### Conversational Agent
```bash
# First question
curl -X POST http://localhost:5000/agent_ask \
  -H "Content-Type: application/json" \
  -d '{"question": "I have adductor pain"}'

# Follow-up question (uses context)
curl -X POST http://localhost:5000/agent_ask \
  -H "Content-Type: application/json" \
  -d '{"question": "what exercises can I do?"}'
```

### Health Check
```bash
curl http://localhost:5000/health
```

## Logging

All operations are logged using Python's logging module:
- Request/response logging
- Error tracking
- Performance metrics
- Context awareness logging

## Performance Optimizations

1. **MCP Client**: Direct HTTP communication with MCP server
2. **No Code Duplication**: Reuses MCP server database
3. **Centralized Database**: Single source of truth
4. **Context Awareness**: Maintains conversation state
5. **Conversation Memory**: Efficient memory management

## Error Handling

- **MCP Server Unavailable**: Returns connection error message
- **Agent Timeout**: Falls back to direct MCP search
- **Invalid Requests**: Returns appropriate error messages
- **Memory Issues**: Automatic memory cleanup

## Development

### Running the Server
```bash
python Langapproach_mcp_client.py
```

### Prerequisites
1. MCP Medical Server must be running on port 8000
2. OpenAI API key must be set
3. All dependencies installed

### Testing
```bash
# Test fast search
curl -X POST http://localhost:5000/fast_ask \
  -H "Content-Type: application/json" \
  -d '{"question": "test query"}'

# Test health
curl http://localhost:5000/health
```

## Troubleshooting

### Common Issues

1. **"MCP server not running"**
   - Ensure MCP Medical Server is running on port 8000
   - Check server logs for connection errors

2. **"Agent reached limit"**
   - Normal behavior - falls back to direct MCP search
   - Check agent configuration if happening frequently

3. **Memory issues**
   - Use `/memory/clear` endpoint to reset
   - Check memory status with `/memory/status`

### Debug Information

- All requests/responses are logged
- Health endpoint provides system status
- Memory status shows conversation context
- Error messages include detailed information
