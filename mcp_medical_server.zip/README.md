# Medical Knowledge MCP Server

A production-ready Model Context Protocol (MCP) server for medical knowledge retrieval using ChromaDB and BGE embeddings. This server provides semantic search capabilities over medical literature and knowledge bases.

## Features

- **Semantic Medical Search**: Search medical knowledge using natural language queries
- **Specialized Search Tools**: Condition-specific, treatment-specific, and symptom-specific search
- **TTL Cache Management**: Intelligent caching with automatic expiration to prevent memory bloat
- **Configurable Response Length**: Adjustable content snippet length for different use cases
- **Production Ready**: Comprehensive error handling, logging, and monitoring
- **MCP Compliant**: Full Model Context Protocol compatibility for AI client integration

## Quick Start

### Prerequisites

- Python 3.8+
- ChromaDB database with medical knowledge base
- Required Python packages (see requirements.txt)

### Installation

1. **Clone and setup**:
   ```bash
   git clone <repository-url>
   cd mcp-server
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure database**:
   - Ensure your ChromaDB database is at `./chroma_db_collective`
   - Collection name should be `books_collection`
   - Database should contain medical documents with proper metadata

4. **Run the server**:
   ```bash
   python mcp_medical_server.py
   ```

## Available Tools

### 1. `search_medical_knowledge`
General medical knowledge search with configurable parameters.

**Parameters**:
- `query` (required): Medical question or topic to search for
- `top_k` (optional): Number of results to return (default: 5, max: 10)
- `max_length` (optional): Maximum content snippet length (default: 500, max: 2000)

**Example**:
```json
{
  "query": "diabetes treatment options",
  "top_k": 3,
  "max_length": 800
}
```

### 2. `search_by_condition`
Search specifically for medical conditions, symptoms, and treatments.

**Parameters**:
- `condition` (required): Medical condition name (e.g., "diabetes", "hypertension")
- `max_length` (optional): Maximum content snippet length (default: 400, max: 2000)

**Example**:
```json
{
  "condition": "diabetes",
  "max_length": 600
}
```

### 3. `search_by_treatment`
Search for information about medical treatments, therapies, and procedures.

**Parameters**:
- `treatment` (required): Treatment name (e.g., "insulin therapy", "surgery")
- `max_length` (optional): Maximum content snippet length (default: 400, max: 2000)

**Example**:
```json
{
  "treatment": "insulin therapy",
  "max_length": 500
}
```

### 4. `search_by_symptom`
Search for symptoms and their potential causes or related conditions.

**Parameters**:
- `symptom` (required): Symptom to search for (e.g., "fever", "chest pain")
- `max_length` (optional): Maximum content snippet length (default: 400, max: 2000)

**Example**:
```json
{
  "symptom": "chest pain",
  "max_length": 400
}
```

### 5. `get_database_info`
Get database statistics and status information.

**Parameters**: None

## Client Integration Examples

### Python MCP Client

```python
import asyncio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    # Connect to the MCP server
    server_params = StdioServerParameters(
        command="python",
        args=["mcp_medical_server.py"]
    )
    
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            # Initialize the session
            await session.initialize()
            
            # Search for medical knowledge
            result = await session.call_tool(
                "search_medical_knowledge",
                {
                    "query": "diabetes treatment options",
                    "top_k": 3,
                    "max_length": 800
                }
            )
            
            print("Search Results:")
            for content in result.content:
                print(content.text)

if __name__ == "__main__":
    asyncio.run(main())
```

### JavaScript/TypeScript MCP Client

```typescript
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

async function main() {
  const transport = new StdioClientTransport({
    command: 'python',
    args: ['mcp_medical_server.py']
  });
  
  const client = new Client({
    name: 'medical-client',
    version: '1.0.0'
  }, {
    capabilities: {}
  });
  
  await client.connect(transport);
  
  // Search for medical knowledge
  const result = await client.callTool({
    name: 'search_medical_knowledge',
    arguments: {
      query: 'diabetes treatment options',
      top_k: 3,
      max_length: 800
    }
  });
  
  console.log('Search Results:', result.content);
}

main().catch(console.error);
```

### Claude Desktop Integration

Add to your Claude Desktop configuration (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "medical-knowledge": {
      "command": "python",
      "args": ["/path/to/mcp_medical_server.py"],
      "env": {}
    }
  }
}
```

### Cursor IDE Integration

Add to your Cursor MCP configuration:

```json
{
  "mcpServers": {
    "medical-knowledge": {
      "command": "python",
      "args": ["mcp_medical_server.py"],
      "cwd": "/path/to/your/project"
    }
  }
}
```

## Configuration

### Environment Variables

The server uses the following configuration (set in your environment or `.env` file):

```bash
# Database Configuration
CHROMA_DB_PATH=./chroma_db_collective
CHROMA_COLLECTION_NAME=books_collection
EMBEDDING_MODEL=BAAI/bge-small-en-v1.5

# Cache Configuration
CACHE_TTL_SECONDS=3600  # 1 hour cache TTL
```

### Database Setup

1. **Prepare your medical documents**:
   - Ensure documents are in text format
   - Include relevant metadata (filename, chunk_id, etc.)
   - Use the same embedding model (BGE) for consistency

2. **Database structure**:
   ```
   chroma_db_collective/
   ├── chroma.sqlite3
   └── [collection-uuid]/
       ├── data_level0.bin
       ├── header.bin
       ├── index_metadata.pickle
       ├── length.bin
       └── link_lists.bin
   ```

## Testing

### Run Unit Tests

```bash
# Run all tests
python test_mcp_medical_server.py

# Run schema validation tests
python test_schema_validation.py

# Run with pytest (if installed)
pytest test_mcp_medical_server.py -v
```

### Test Coverage

The test suite covers:
- TTL cache functionality
- Database operations with mocked ChromaDB
- MCP tool implementations
- JSON schema validation
- Error handling scenarios

## Production Considerations

### Performance Optimization

1. **Cache Management**: The server uses TTL-based caching to prevent memory bloat
2. **Response Truncation**: Configurable content length limits for optimal performance
3. **Database Indexing**: Ensure your ChromaDB collection is properly indexed

### Monitoring

The server provides comprehensive logging:
- Search query logging
- Cache hit/miss statistics
- Error tracking and reporting
- Database connection status

### Security

- No API keys required (uses local BGE embeddings)
- Input validation on all parameters
- Response length limits to prevent abuse
- Error message sanitization

## Troubleshooting

### Common Issues

1. **Database Connection Errors**:
   - Verify ChromaDB path exists
   - Check collection name matches configuration
   - Ensure database is not corrupted

2. **Import Errors**:
   - Install all requirements: `pip install -r requirements.txt`
   - Check Python version (3.8+ required)

3. **Memory Issues**:
   - Cache TTL is set to 1 hour by default
   - Adjust `CACHE_TTL_SECONDS` if needed
   - Monitor cache size via `get_database_info` tool

### Debug Mode

Enable debug logging by setting the log level:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## API Reference

### Response Format

All search tools return responses in the following format:

```
Medical Knowledge Search Results for: '[query]'
Found [N] relevant documents

--- Result 1 (Relevance: XX%) ---
Source: [filename]_chunk_[id]
[Content snippet...]

--- Result 2 (Relevance: XX%) ---
Source: [filename]_chunk_[id]
[Content snippet...]
```

### Error Handling

The server handles errors gracefully:
- Invalid parameters return descriptive error messages
- Database errors are logged and returned to client
- Network issues are handled with appropriate timeouts

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

[Add your license information here]

## Support

For issues and questions:
- Check the troubleshooting section
- Review the test files for usage examples
- Open an issue on the repository
